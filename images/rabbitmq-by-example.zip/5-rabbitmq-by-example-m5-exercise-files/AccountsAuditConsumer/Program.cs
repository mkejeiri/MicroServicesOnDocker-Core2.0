﻿namespace AccountsAuditConsumer
{
    class Program
    {
        static void Main(string[] args)
        {        
        }
    }
}
